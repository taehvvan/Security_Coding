package member;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;

public class MemberService {

	MemberDAO dao;
	
	public MemberService(ServletContext context) {
		System.out.println("MemberService 생성");
		// dao = new MemberDAO();
		dao = new MemberDAO(context);
	}
	
	public MemberService(ServletConfig config) {
		dao = new MemberDAO(config);
	}

	public int save(Member member) {
		// password를 암호화, 기타 작업 수행 (가공)
		return dao.save(member);
	}

	public boolean loginConfirm(String id, String password) {
		Member dbMember = dao.findById(id);
		System.out.println("****************");
		System.out.println(dbMember);
		if(dbMember.getId().equals(id) && dbMember.getPassword().equals(password)) {
			return true;
		}
		return false;
	}

}
