package member;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/my/*")
public class MyController extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		if(req.getRequestURI().split("/").length < 1) {
			return;
		}
		
		// localhost:8888/my/add
		String command = req.getRequestURI().split("/")[2];
		
		switch(command) {
			case "add":
				System.out.println("listener add");
				req.setAttribute("id", "test");
				break;
			case "replace":
				System.out.println("listener replace");
				req.setAttribute("id", "replace test");
				break;
			case "remove":
				System.out.println("listener remove");
				req.removeAttribute("id");
				break;
		}
	}
	
}
