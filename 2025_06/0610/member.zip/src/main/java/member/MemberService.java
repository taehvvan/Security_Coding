package member;

public class MemberService {

	MemberDAO dao;
	
	public MemberService() {
		System.out.println("MemberService 생성");
		dao = new MemberDAO();
	}
	
	public int save(Member member) {
		// password를 암호화, 기타 작업 수행 (가공)
		return dao.save(member);
	}

	public boolean loginConfirm(String id, String password) {
		Member dbMember = dao.findById(id);
		if(dbMember.getId().equals(id) && dbMember.getPassword().equals(password)) {
			return true;
		}
		return false;
	}

}
